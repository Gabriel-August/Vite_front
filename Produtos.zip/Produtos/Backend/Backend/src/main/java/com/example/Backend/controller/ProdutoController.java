package com.example.Backend.controller;

import com.example.Backend.model.Produto;
import com.example.Backend.Repository.ProdutoRepository;
import com.example.Backend.Repository.CategoriaRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/produtos")
@CrossOrigin(origins = "*")
public class ProdutoController {
    private final ProdutoRepository produtoRepo;
    private final CategoriaRepository categoriaRepo;

    public ProdutoController(ProdutoRepository produtoRepo, CategoriaRepository categoriaRepo) {
        this.produtoRepo = produtoRepo;
        this.categoriaRepo = categoriaRepo;
    }

    @GetMapping
    public List<Produto> findAll() {
        return produtoRepo.findAll();
    }

    @PostMapping
    public Produto create(@RequestBody Produto produto) {
        if (produto.getCategoria() != null && produto.getCategoria().getId() != null) {
            produto.setCategoria(categoriaRepo.findById(produto.getCategoria().getId()).orElse(null));
        }
        return produtoRepo.save(produto);
    }

    @PutMapping("/{id}")
    public Produto update(@PathVariable Long id, @RequestBody Produto produto) {
        produto.setId(id);
        if (produto.getCategoria() != null && produto.getCategoria().getId() != null) {
            produto.setCategoria(categoriaRepo.findById(produto.getCategoria().getId()).orElse(null));
        }
        return produtoRepo.save(produto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        produtoRepo.deleteById(id);
    }
}
