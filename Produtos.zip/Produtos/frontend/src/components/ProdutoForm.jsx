import React, { useState } from 'react';

const ProdutoForm = ({ categorias, refresh }) => {
  const [nome, setNome] = useState('');
  const [preco, setPreco] = useState('');
  const [categoriaId, setCategoriaId] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch('http://localhost:8080/produtos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nome,
        preco: parseFloat(preco),
        categoria: { id: parseInt(categoriaId) },
      }),
    });
    setNome('');
    setPreco('');
    setCategoriaId('');
    refresh();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Nome do produto" value={nome} onChange={(e) => setNome(e.target.value)} />
      <input placeholder="Preço" type="number" value={preco} onChange={(e) => setPreco(e.target.value)} />
      <select value={categoriaId} onChange={(e) => setCategoriaId(e.target.value)}>
        <option value="">Selecione a categoria</option>
        {categorias.map((cat) => (
          <option key={cat.id} value={cat.id}>{cat.nome}</option>
        ))}
      </select>
      <button type="submit">Adicionar Produto</button>
    </form>
  );
};

export default ProdutoForm;
