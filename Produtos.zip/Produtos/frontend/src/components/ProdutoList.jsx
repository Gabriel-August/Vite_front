import React from 'react';

const ProdutoList = ({ produtos, refresh }) => {
  const handleDelete = async (id) => {
    await fetch(`http://localhost:8080/produtos/${id}`, { method: 'DELETE' });
    refresh();
  };

  return (
    <ul>
      {produtos.map((prod) => (
        <li key={prod.id}>
          {prod.nome} - {prod.preco} - {prod.categoria?.nome}
          <button onClick={() => handleDelete(prod.id)}>Excluir</button>
        </li>
      ))}
    </ul>
  );
};

export default ProdutoList;
