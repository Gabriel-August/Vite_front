import React, { useState } from 'react';

const CategoriaForm = ({ refresh }) => {
  const [nome, setNome] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch('http://localhost:8080/categorias', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome }),
    });
    setNome('');
    refresh();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Nome da categoria"
        value={nome}
        onChange={(e) => setNome(e.target.value)}
      />
      <button type="submit">Adicionar Categoria</button>
    </form>
  );
};

// ESSA LINHA É FUNDAMENTAL
export default CategoriaForm;