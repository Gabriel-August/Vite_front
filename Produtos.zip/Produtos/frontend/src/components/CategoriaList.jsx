import React from 'react';

const CategoriaList = ({ categorias, refresh }) => {
  const handleDelete = async (id) => {
    await fetch(`http://localhost:8080/categorias/${id}`, { method: 'DELETE' });
    refresh();
  };

  return (
    <ul>
      {categorias.map((cat) => (
        <li key={cat.id}>
          {cat.nome} <button onClick={() => handleDelete(cat.id)}>Excluir</button>
        </li>
      ))}
    </ul>
  );
};

export default CategoriaList;