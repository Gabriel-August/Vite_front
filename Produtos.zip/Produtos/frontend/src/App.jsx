import React, { useState, useEffect } from 'react';
import CategoriaList from './components/CategoriaList';
import CategoriaForm from './components/CategoriaForm';
import ProdutoList from './components/ProdutoList';
import ProdutoForm from './components/ProdutoForm';

const App = () => {
  const [categorias, setCategorias] = useState([]);
  const [produtos, setProdutos] = useState([]);

  const fetchCategorias = async () => {
    const res = await fetch('http://localhost:8080/categorias');
    const data = await res.json();

    // Verifica se existe a propriedade 'content' para extrair o array
    if (data.content) {
      setCategorias(data.content);
    } else {
      setCategorias(data);
    }
  };

  const fetchProdutos = async () => {
    const res = await fetch('http://localhost:8080/produtos');
    const data = await res.json();
    setProdutos(data);
  };

  useEffect(() => {
    fetchCategorias();
    fetchProdutos();
  }, []);

  return (
    <div>
      <h1>Gerenciamento de Categorias e Produtos</h1>
      <CategoriaForm refresh={fetchCategorias} />
      <CategoriaList categorias={categorias} refresh={fetchCategorias} />

      <ProdutoForm categorias={categorias} refresh={fetchProdutos} />
      <ProdutoList produtos={produtos} refresh={fetchProdutos} />
    </div>
  );
};

export default App;
