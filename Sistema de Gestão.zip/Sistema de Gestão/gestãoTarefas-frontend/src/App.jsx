import React, { useState, useEffect } from "react";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import Chart from "./components/Chart"; // Componente para gráfico

import "./App.css";

const API_URL = "http://localhost:8080/api/tarefas"; // Endpoint do Spring Boot

export default function App() {
  const [tarefas, setTarefas] = useState([]);
  const [categoriaFiltro, setCategoriaFiltro] = useState(""); // Filtro por categoria
  const [categorias, setCategorias] = useState([]); // Armazenar categorias únicas

  // 🔹 Buscar tarefas do backend
  useEffect(() => {
    fetch(API_URL)
      .then((res) => {
        if (!res.ok) {
          throw new Error("Erro ao carregar tarefas");
        }
        return res.json();
      })
      .then((data) => {
        setTarefas(data);
        const categoriasUnicas = [...new Set(data.map((t) => t.categoria))];
        setCategorias(categoriasUnicas);
      })
      .catch((err) => console.error("Erro ao carregar tarefas:", err));
  }, []);

  // 🔹 Filtrar tarefas por categoria
  const tarefasFiltradas = categoriaFiltro
    ? tarefas.filter((t) => t.categoria === categoriaFiltro)
    : tarefas;

  // 🔹 Adicionar tarefa
  const addTarefa = (tarefa) => {
    fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tarefa), // Envia os dados em JSON
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Erro ao adicionar tarefa");
        }
        return res.json();
      })
      .then((novaTarefa) => {
        setTarefas([...tarefas, novaTarefa]);
      })
      .catch((err) => console.error("Erro ao adicionar tarefa:", err));
  };

  // 🔹 Atualizar status da tarefa (concluída / pendente)
  const toggleStatus = (id, status) => {
    fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }), // Atualiza o status
    })
      .then(() => {
        setTarefas(tarefas.map((t) => (t.id === id ? { ...t, status } : t)));
      })
      .catch((err) => console.error("Erro ao atualizar tarefa:", err));
  };

  // 🔹 Excluir tarefa
  const deleteTarefa = (id) => {
    fetch(`${API_URL}/${id}`, { method: "DELETE" })
      .then(() => setTarefas(tarefas.filter((t) => t.id !== id)))
      .catch((err) => console.error("Erro ao excluir tarefa:", err));
  };

  return (
    <div className="app-container">
      <h1>🌿 EcoTasks</h1>
      <div>
        <label htmlFor="categoriaFiltro">Filtrar por categoria: </label>
        <select
          id="categoriaFiltro"
          value={categoriaFiltro}
          onChange={(e) => setCategoriaFiltro(e.target.value)}
        >
          <option value="">Todas</option>
          {categorias.map((categoria, index) => (
            <option key={index} value={categoria}>
              {categoria}
            </option>
          ))}
        </select>
      </div>
      <TaskForm onAdd={addTarefa} />
      <TaskList
        tarefas={tarefasFiltradas}
        onToggle={toggleStatus}
        onDelete={deleteTarefa}
      />
      <Chart tarefas={tarefasFiltradas} /> {/* Gráfico */}
    </div>
  );
}
