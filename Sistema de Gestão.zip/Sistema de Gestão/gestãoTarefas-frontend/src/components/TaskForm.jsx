import { useState } from "react";

export default function TaskForm({ onAdd }) {
  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [categoria, setCategoria] = useState("");
  const [status, setStatus] = useState("pendente");
  const [data, setData] = useState(""); // Campo de data

  const handleSubmit = (e) => {
    e.preventDefault();
    const novaTarefa = {
      titulo,
      descricao,
      categoria,
      status,
      data, // Adicionando o campo de data
    };
    onAdd(novaTarefa);
    setTitulo("");
    setDescricao("");
    setCategoria("");
    setStatus("pendente");
    setData(""); // Resetando o campo de data
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Título:</label>
        <input
          type="text"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
        />
      </div>
      <div>
        <label>Descrição:</label>
        <input
          type="text"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
        />
      </div>
      <div>
        <label>Categoria:</label>
        <input
          type="text"
          value={categoria}
          onChange={(e) => setCategoria(e.target.value)}
        />
      </div>
      <div>
        <label>Status:</label>
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="pendente">Pendente</option>
          <option value="concluída">Concluída</option>
        </select>
      </div>
      <div>
        <label>Data:</label>
        <input
          type="date"
          value={data}
          onChange={(e) => setData(e.target.value)}
        />
      </div>
      <button type="submit">Adicionar</button>
    </form>
  );
}
