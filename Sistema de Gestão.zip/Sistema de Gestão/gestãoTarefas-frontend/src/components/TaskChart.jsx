// src/components/TaskChart.jsx
import React from "react";
import { Bar } from "react-chartjs-2"; // Importa o componente de gráfico de barras
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

// Registra os componentes necessários do Chart.js
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const TaskChart = ({ completedTasks, pendingTasks }) => {
  // Definindo os dados para o gráfico
  const data = {
    labels: ["Tarefas"], // Título da categoria
    datasets: [
      {
        label: "Concluídas",
        data: [completedTasks], // Número de tarefas concluídas
        backgroundColor: "rgba(75, 192, 192, 0.2)", // Cor da barra para tarefas concluídas
        borderColor: "rgba(75, 192, 192, 1)", // Cor da borda da barra
        borderWidth: 1,
      },
      {
        label: "Pendentes",
        data: [pendingTasks], // Número de tarefas pendentes
        backgroundColor: "rgba(255, 99, 132, 0.2)", // Cor da barra para tarefas pendentes
        borderColor: "rgba(255, 99, 132, 1)", // Cor da borda da barra
        borderWidth: 1,
      },
    ],
  };

  // Definindo as opções do gráfico
  const options = {
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: "Comparação de Tarefas: Concluídas x Pendentes",
      },
      tooltip: {
        enabled: true,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return <Bar data={data} options={options} />;
};

export default TaskChart;
