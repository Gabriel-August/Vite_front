import React, { useState, useEffect } from "react";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import Chart from "./components/Chart";

import "./App.css";

const API_URL = "http://localhost:8080/api/tarefas";

export default function App() {
  const [tarefas, setTarefas] = useState([]);
  const [categoriaFiltro, setCategoriaFiltro] = useState("");
  const [categorias, setCategorias] = useState([]);

  // 🔹 Buscar tarefas do backend
  useEffect(() => {
    fetch(API_URL)
      .then((res) => {
        if (!res.ok) {
          throw new Error("Erro ao carregar tarefas");
        }
        return res.json();
      })
      .then((data) => {
        setTarefas(data);
        const categoriasUnicas = [...new Set(data.map((t) => t.categoria))];
        setCategorias(categoriasUnicas);
      })
      .catch((err) => console.error("Erro ao carregar tarefas:", err));
  }, []);

  // 🔹 Filtrar tarefas por categoria
  const tarefasFiltradas = categoriaFiltro
    ? tarefas.filter((t) => t.categoria === categoriaFiltro)
    : tarefas;

  // 🔹 Adicionar tarefa (CORRIGIDO - apenas 3 campos)
  const addTarefa = (tarefa) => {
    // 🔴 APENAS OS 3 CAMPOS QUE A API ESPERA
    const tarefaParaAPI = {
      titulo: tarefa.titulo || "Sem título",
      categoria: tarefa.categoria || "Geral",
      status: false // 🔴 DEVE SER BOOLEAN, NÃO STRING
    };
    
    console.log("Enviando para API:", tarefaParaAPI);
    
    fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tarefaParaAPI),
    })
      .then((res) => {
        console.log("Status:", res.status, res.statusText);
        if (!res.ok) {
          // Tenta ler mensagem de erro
          return res.text().then(text => {
            console.error("Resposta de erro:", text);
            throw new Error(`Erro ${res.status}: ${text || res.statusText}`);
          });
        }
        return res.json();
      })
      .then((novaTarefa) => {
        console.log("Tarefa criada:", novaTarefa);
        setTarefas([...tarefas, novaTarefa]);
        
        // Atualizar lista de categorias
        if (novaTarefa.categoria && !categorias.includes(novaTarefa.categoria)) {
          setCategorias([...categorias, novaTarefa.categoria]);
        }
      })
      .catch((err) => {
        console.error("Erro completo:", err);
        alert("Erro: " + err.message);
      });
  };

  // 🔹 Atualizar status da tarefa (CORRIGIDO para Boolean)
  const toggleStatus = (id, statusAtual) => {
    // statusAtual é um Boolean (true/false)
    const novoStatus = !statusAtual; // Inverte o status
    
    fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        status: novoStatus 
        // ⚠️ IMPORTANTE: Se seu PUT requer o objeto completo, 
        // você precisa enviar todos os campos:
        // Encontre a tarefa primeiro:
        // const tarefaParaAtualizar = tarefas.find(t => t.id === id);
        // body: JSON.stringify({
        //   ...tarefaParaAtualizar,
        //   status: novoStatus
        // })
      }),
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error(`Erro ${res.status}: ${res.statusText}`);
        }
        return res.json();
      })
      .then((tarefaAtualizada) => {
        setTarefas(tarefas.map((t) => 
          t.id === id ? tarefaAtualizada : t
        ));
      })
      .catch((err) => {
        console.error("Erro ao atualizar tarefa:", err);
        alert(`Erro ao atualizar: ${err.message}`);
      });
  };

  // 🔹 Excluir tarefa
  const deleteTarefa = (id) => {
    fetch(`${API_URL}/${id}`, { method: "DELETE" })
      .then(() => setTarefas(tarefas.filter((t) => t.id !== id)))
      .catch((err) => console.error("Erro ao excluir tarefa:", err));
  };

  return (
    <div className="app-container">
      <h1>🌿 EcoTasks</h1>
      <div>
        <label htmlFor="categoriaFiltro">Filtrar por categoria: </label>
        <select
          id="categoriaFiltro"
          value={categoriaFiltro}
          onChange={(e) => setCategoriaFiltro(e.target.value)}
        >
          <option value="">Todas</option>
          {categorias.map((categoria, index) => (
            <option key={index} value={categoria}>
              {categoria}
            </option>
          ))}
        </select>
      </div>
      <TaskForm onAdd={addTarefa} />
      <TaskList
        tarefas={tarefasFiltradas}
        onToggle={toggleStatus}
        onDelete={deleteTarefa}
      />
      <Chart tarefas={tarefasFiltradas} />
    </div>
  );
}