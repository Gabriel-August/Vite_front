// src/components/Chart.jsx
import React from "react";
import { Bar } from "react-chartjs-2"; // Componente de gráfico de barras do react-chartjs-2
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

// Registra os componentes do Chart.js
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const Chart = ({ tarefas }) => {
  // Contagem das tarefas concluídas e pendentes
  const tarefasConcluidas = tarefas.filter((t) => t.status).length;
  const tarefasPendentes = tarefas.length - tarefasConcluidas;

  // Dados do gráfico
  const data = {
    labels: ["Tarefas"], // A única categoria será "Tarefas"
    datasets: [
      {
        label: "Concluídas",
        data: [tarefasConcluidas], // Contagem de tarefas concluídas
        backgroundColor: "rgba(75, 192, 192, 0.2)", // Cor da barra para tarefas concluídas
        borderColor: "rgba(75, 192, 192, 1)", // Cor da borda
        borderWidth: 1,
      },
      {
        label: "Pendentes",
        data: [tarefasPendentes], // Contagem de tarefas pendentes
        backgroundColor: "rgba(255, 99, 132, 0.2)", // Cor da barra para tarefas pendentes
        borderColor: "rgba(255, 99, 132, 1)", // Cor da borda
        borderWidth: 1,
      },
    ],
  };

  // Opções do gráfico
  const options = {
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: "Tarefas Concluídas vs Pendentes",
      },
      tooltip: {
        enabled: true,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return <Bar data={data} options={options} />;
};

export default Chart;
