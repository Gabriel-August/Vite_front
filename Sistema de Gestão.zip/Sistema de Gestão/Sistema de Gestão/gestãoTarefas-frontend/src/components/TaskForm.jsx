import React, { useState } from "react";

const TaskForm = ({ onAdd }) => {
  const [titulo, setTitulo] = useState("");
  const [categoria, setCategoria] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!titulo.trim()) {
      alert("O título é obrigatório!");
      return;
    }

    // 🔴 APENAS OS CAMPOS QUE A API ESPERA
    const novaTarefa = {
      titulo: titulo,
      categoria: categoria || "Geral",
      // NÃO envie status aqui - ele será definido como false automaticamente
      // NÃO envie: descricao, prioridade, dataCriacao, etc.
    };

    console.log("Enviando tarefa:", novaTarefa);
    onAdd(novaTarefa);
    
    // Limpar formulário
    setTitulo("");
    setCategoria("");
  };

  return (
    <form onSubmit={handleSubmit} className="task-form">
      <div>
        <label>Título *</label>
        <input
          type="text"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          placeholder="Digite o título da tarefa"
          required
        />
      </div>
      
      <div>
        <label>Categoria</label>
        <input
          type="text"
          value={categoria}
          onChange={(e) => setCategoria(e.target.value)}
          placeholder="Ex: Meio Social"
        />
      </div>
      
      <button type="submit">Adicionar Tarefa</button>
    </form>
  );
};

export default TaskForm;