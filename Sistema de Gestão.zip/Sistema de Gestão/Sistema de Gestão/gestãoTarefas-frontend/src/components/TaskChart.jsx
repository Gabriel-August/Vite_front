// src/components/Chart.jsx
import React from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from "chart.js";

// Registra os componentes necessários do Chart.js
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const Chart = ({ tarefas }) => {
  // Verifica se tarefas é um array válido
  if (!tarefas || !Array.isArray(tarefas)) {
    return <p>Carregando dados do gráfico...</p>;
  }

  // Calcula tarefas concluídas e pendentes
  // LEMBRE-SE: status é Boolean (true = concluída, false = pendente)
  const completedTasks = tarefas.filter(tarefa => tarefa.status === true).length;
  const pendingTasks = tarefas.filter(tarefa => tarefa.status === false).length;

  // Agrupa por categoria
  const categorias = [...new Set(tarefas.map(t => t.categoria || "Sem categoria"))];
  const dadosPorCategoria = categorias.map(categoria => {
    const tarefasDaCategoria = tarefas.filter(t => (t.categoria || "Sem categoria") === categoria);
    return {
      categoria,
      concluidas: tarefasDaCategoria.filter(t => t.status === true).length,
      pendentes: tarefasDaCategoria.filter(t => t.status === false).length,
      total: tarefasDaCategoria.length
    };
  });

  // Dados para o gráfico de barras (comparação geral)
  const dataBar = {
    labels: ["Tarefas"],
    datasets: [
      {
        label: "Concluídas",
        data: [completedTasks],
        backgroundColor: "rgba(75, 192, 192, 0.7)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 2,
      },
      {
        label: "Pendentes",
        data: [pendingTasks],
        backgroundColor: "rgba(255, 99, 132, 0.7)",
        borderColor: "rgba(255, 99, 132, 1)",
        borderWidth: 2,
      },
    ],
  };

  // Dados para o gráfico de categorias
  const dataCategorias = {
    labels: categorias,
    datasets: [
      {
        label: "Tarefas por Categoria",
        data: dadosPorCategoria.map(item => item.total),
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 206, 86, 0.7)',
          'rgba(75, 192, 192, 0.7)',
          'rgba(153, 102, 255, 0.7)',
          'rgba(255, 159, 64, 0.7)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: "Estatísticas das Tarefas",
        font: {
          size: 18
        }
      },
      tooltip: {
        enabled: true,
      },
      legend: {
        position: 'top',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1
        }
      },
    },
  };

  const optionsCategorias = {
    ...options,
    plugins: {
      ...options.plugins,
      title: {
        display: true,
        text: "Tarefas por Categoria",
        font: {
          size: 18
        }
      }
    }
  };

  return (
    <div className="chart-container">
      <div style={{ marginBottom: '30px' }}>
        <h3>Progresso Geral</h3>
        <div style={{ height: '300px' }}>
          <Bar data={dataBar} options={options} />
        </div>
        <div style={{ marginTop: '10px', textAlign: 'center' }}>
          <p><strong>Concluídas:</strong> {completedTasks} | <strong>Pendentes:</strong> {pendingTasks} | <strong>Total:</strong> {tarefas.length}</p>
          <p><strong>Progresso:</strong> {tarefas.length > 0 ? Math.round((completedTasks / tarefas.length) * 100) : 0}%</p>
        </div>
      </div>
      
      <div>
        <h3>Distribuição por Categoria</h3>
        <div style={{ height: '300px' }}>
          <Bar data={dataCategorias} options={optionsCategorias} />
        </div>
      </div>
    </div>
  );
};

export default Chart;