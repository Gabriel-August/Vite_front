package com.example.eco_tasks_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoTasksBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
