package com.example.eco_tasks_backend.repository;


import com.example.eco_tasks_backend.model.Tarefa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TarefaRepository extends JpaRepository<Tarefa, Long> {

}
