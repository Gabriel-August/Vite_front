package com.example.eco_tasks_backend.controller;

import com.example.eco_tasks_backend.model.Tarefa;
import com.example.eco_tasks_backend.service.TarefaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tarefas")
@CrossOrigin(origins = "*") // permite conexão com frontend (React)

public class TarefaController {
    private final TarefaService service;

    public TarefaController(TarefaService service) {
        this.service = service;
    }

    @GetMapping
    public List<Tarefa> listar() {
        return service.listarTodas();
    }

    @PostMapping
    public Tarefa criar(@RequestBody Tarefa tarefa) {
        return service.salvar(tarefa);
    }

    @PutMapping("/{id}")
    public Tarefa atualizarStatus(@PathVariable Long id, @RequestBody Tarefa tarefa) {
        return service.atualizarStatus(id, tarefa.getStatus());
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        service.deletar(id);
    }

}
