package com.example.eco_tasks_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcoTasksBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcoTasksBackendApplication.class, args);
	}

}
