package com.example.eco_tasks_backend.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tarefas")
@Data
public class Tarefa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;
    private String categoria;
    private Boolean status = false;

}
