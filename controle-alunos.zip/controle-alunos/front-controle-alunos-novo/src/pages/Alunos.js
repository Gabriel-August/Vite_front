import React, { useState, useEffect } from "react";
import axios from "axios";

const Alunos = () => {
  const [alunos, setAlunos] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/alunos")
      .then((res) => setAlunos(res.data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div className="container mt-4">
      <h2>Alunos</h2>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Telefone</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {alunos.map((a) => (
            <tr key={a.id}>
              <td>{a.id}</td>
              <td>{a.nome}</td>
              <td>{a.email}</td>
              <td>{a.telefone}</td>
              <td>{a.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Alunos;
