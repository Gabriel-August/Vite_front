import React, { useState } from "react";
import axios from "axios";

export default function Notas() {
  const [notas, setNotas] = useState([]);
  const [form, setForm] = useState({
    aluno_id: "",
    disciplina_id: "",
    bimestre: "",
    nota: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/notas", form);
    setForm({ aluno_id: "", disciplina_id: "", bimestre: "", nota: "" });
    const res = await axios.get(`http://localhost:5000/notas/${form.aluno_id}`);
    setNotas(res.data.notas);
  };

  return (
    <div>
      <h2>Notas dos Alunos</h2>
      <form onSubmit={handleSubmit} className="row g-3 mb-4">
        <div className="col-md-2">
          <input
            className="form-control"
            placeholder="Aluno ID"
            value={form.aluno_id}
            onChange={(e) => setForm({ ...form, aluno_id: e.target.value })}
          />
        </div>
        <div className="col-md-2">
          <input
            className="form-control"
            placeholder="Disciplina ID"
            value={form.disciplina_id}
            onChange={(e) =>
              setForm({ ...form, disciplina_id: e.target.value })
            }
          />
        </div>
        <div className="col-md-2">
          <input
            className="form-control"
            placeholder="Bimestre"
            value={form.bimestre}
            onChange={(e) => setForm({ ...form, bimestre: e.target.value })}
          />
        </div>
        <div className="col-md-2">
          <input
            className="form-control"
            placeholder="Nota"
            value={form.nota}
            onChange={(e) => setForm({ ...form, nota: e.target.value })}
          />
        </div>
        <div className="col-md-2">
          <button type="submit" className="btn btn-success w-100">
            Registrar
          </button>
        </div>
      </form>

      <table className="table table-striped">
        <thead>
          <tr>
            <th>Disciplina</th>
            <th>Bimestre</th>
            <th>Nota</th>
          </tr>
        </thead>
        <tbody>
          {notas.map((n, i) => (
            <tr key={i}>
              <td>{n.disciplina_id}</td>
              <td>{n.bimestre}</td>
              <td>{n.nota}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
