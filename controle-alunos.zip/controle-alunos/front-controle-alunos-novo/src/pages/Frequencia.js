import React, { useState } from "react";
import axios from "axios";

export default function Frequencias() {
  const [frequencias, setFrequencias] = useState([]);
  const [form, setForm] = useState({
    aluno_id: "",
    disciplina_id: "",
    data: "",
    presente: true,
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/frequencias", form);
    const res = await axios.get(
      `http://localhost:5000/frequencias/${form.aluno_id}`
    );
    setFrequencias(res.data);
  };

  return (
    <div>
      <h2>Controle de Frequência</h2>
      <form onSubmit={handleSubmit} className="row g-3 mb-4">
        <div className="col-md-2">
          <input
            className="form-control"
            placeholder="Aluno ID"
            value={form.aluno_id}
            onChange={(e) => setForm({ ...form, aluno_id: e.target.value })}
          />
        </div>
        <div className="col-md-2">
          <input
            className="form-control"
            placeholder="Disciplina ID"
            value={form.disciplina_id}
            onChange={(e) =>
              setForm({ ...form, disciplina_id: e.target.value })
            }
          />
        </div>
        <div className="col-md-2">
          <input
            type="date"
            className="form-control"
            value={form.data}
            onChange={(e) => setForm({ ...form, data: e.target.value })}
          />
        </div>
        <div className="col-md-2">
          <select
            className="form-select"
            value={form.presente}
            onChange={(e) =>
              setForm({ ...form, presente: e.target.value === "true" })
            }
          >
            <option value="true">Presente</option>
            <option value="false">Faltou</option>
          </select>
        </div>
        <div className="col-md-2">
          <button type="submit" className="btn btn-primary w-100">
            Registrar
          </button>
        </div>
      </form>

      <table className="table table-striped">
        <thead>
          <tr>
            <th>Data</th>
            <th>Disciplina</th>
            <th>Presente</th>
          </tr>
        </thead>
        <tbody>
          {frequencias.map((f, i) => (
            <tr key={i}>
              <td>{f.data}</td>
              <td>{f.disciplina_id}</td>
              <td>{f.presente ? "✅" : "❌"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
