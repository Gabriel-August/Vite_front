import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Disciplinas() {
  const [disciplinas, setDisciplinas] = useState([]);
  const [form, setForm] = useState({ nome: "", turma_id: "", professor: "" });

  useEffect(() => {
    axios
      .get("http://localhost:5000/disciplinas")
      .then((res) => setDisciplinas(res.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/disciplinas", form);
    setForm({ nome: "", turma_id: "", professor: "" });
    const res = await axios.get("http://localhost:5000/disciplinas");
    setDisciplinas(res.data);
  };

  return (
    <div>
      <h2>Disciplinas</h2>
      <form onSubmit={handleSubmit} className="row g-3 mb-4">
        <div className="col-md-3">
          <input
            className="form-control"
            placeholder="Nome"
            value={form.nome}
            onChange={(e) => setForm({ ...form, nome: e.target.value })}
            required
          />
        </div>
        <div className="col-md-3">
          <input
            className="form-control"
            placeholder="Turma ID"
            value={form.turma_id}
            onChange={(e) => setForm({ ...form, turma_id: e.target.value })}
            required
          />
        </div>
        <div className="col-md-3">
          <input
            className="form-control"
            placeholder="Professor"
            value={form.professor}
            onChange={(e) => setForm({ ...form, professor: e.target.value })}
            required
          />
        </div>
        <div className="col-md-2">
          <button type="submit" className="btn btn-primary w-100">
            Adicionar
          </button>
        </div>
      </form>

      <table className="table table-striped">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Turma ID</th>
            <th>Professor</th>
          </tr>
        </thead>
        <tbody>
          {disciplinas.map((d) => (
            <tr key={d.id}>
              <td>{d.nome}</td>
              <td>{d.turma_id}</td>
              <td>{d.professor}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
