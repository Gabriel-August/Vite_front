import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Turmas() {
  const [turmas, setTurmas] = useState([]);
  const [form, setForm] = useState({ nome: "", curso: "" });

  useEffect(() => {
    axios
      .get("http://localhost:5000/turmas")
      .then((res) => setTurmas(res.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/turmas", form);
    setForm({ nome: "", curso: "" });
    const res = await axios.get("http://localhost:5000/turmas");
    setTurmas(res.data);
  };

  return (
    <div>
      <h2>Gerenciamento de Turmas</h2>
      <form onSubmit={handleSubmit} className="row g-3 mb-4">
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Nome da turma"
            value={form.nome}
            onChange={(e) => setForm({ ...form, nome: e.target.value })}
            required
          />
        </div>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Curso"
            value={form.curso}
            onChange={(e) => setForm({ ...form, curso: e.target.value })}
            required
          />
        </div>
        <div className="col-md-2">
          <button type="submit" className="btn btn-success w-100">
            Adicionar
          </button>
        </div>
      </form>

      <table className="table table-striped">
        <thead>
          <tr>
            <th>Turma</th>
            <th>Curso</th>
          </tr>
        </thead>
        <tbody>
          {turmas.map((t) => (
            <tr key={t.id}>
              <td>{t.nome}</td>
              <td>{t.curso}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
