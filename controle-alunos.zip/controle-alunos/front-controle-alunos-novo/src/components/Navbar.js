import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container">
        <Link className="navbar-brand" to="/">
          Controle de Alunos
        </Link>
        <div>
          <Link className="btn btn-light mx-1" to="/alunos">
            Alunos
          </Link>
          <Link className="btn btn-light mx-1" to="/turmas">
            Turmas
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
