import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Alunos from "./pages/Alunos";
import Turmas from "./pages/Turmas";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route
          path="/"
          element={<h1 className="text-center mt-4">Bem-vindo!</h1>}
        />
        <Route path="/alunos" element={<Alunos />} />
        <Route path="/turmas" element={<Turmas />} />
      </Routes>
    </Router>
  );
}

export default App;
