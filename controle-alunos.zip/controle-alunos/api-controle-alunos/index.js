// index.js
import express from "express";
import cors from "cors";
import mysql from "mysql2/promise";
import admin from "firebase-admin";
import { readFileSync } from "fs";

// ================== FIREBASE ==================
const serviceAccount = JSON.parse(
  readFileSync("./serviceAccountKey.json", "utf-8")
);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const firestore = admin.firestore();

// ================== MYSQL ==================
const db = await mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "aluno",
  database: "controle_alunos",
});

console.log("Conectado ao MySQL");

// ================== EXPRESS ==================
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// ================== ROTAS ==================

// Teste
app.get("/", (req, res) => res.send("API Controle de Alunos funcionando!"));

// --- ALUNOS ---
app.post("/alunos", async (req, res) => {
  const {
    nome,
    data_nascimento,
    endereco,
    telefone,
    email,
    cpf,
    rg,
    foto,
    turma_id,
    status,
  } = req.body;

  try {
    const [result] = await db.execute(
      "INSERT INTO alunos (nome, data_nascimento, endereco, telefone, email, cpf, rg, foto, turma_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [
        nome,
        data_nascimento,
        endereco,
        telefone,
        email,
        cpf,
        rg,
        foto,
        turma_id,
        status,
      ]
    );

    await firestore
      .collection("alunos")
      .doc(result.insertId.toString())
      .set(req.body);

    res.status(200).json({ message: "Aluno criado!", id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao criar aluno");
  }
});

app.get("/alunos", async (req, res) => {
  try {
    const [rows] = await db.execute("SELECT * FROM alunos");
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao listar alunos");
  }
});

// --- TURMAS ---
app.post("/turmas", async (req, res) => {
  const { nome, curso } = req.body;
  try {
    const [result] = await db.execute(
      "INSERT INTO turmas (nome, curso) VALUES (?, ?)",
      [nome, curso]
    );
    await firestore
      .collection("turmas")
      .doc(result.insertId.toString())
      .set(req.body);
    res.json({ message: "Turma criada!", id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao criar turma");
  }
});

app.get("/turmas", async (req, res) => {
  try {
    const [rows] = await db.execute("SELECT * FROM turmas");
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao listar turmas");
  }
});

// --- DISCIPLINAS ---
app.post("/disciplinas", async (req, res) => {
  const { nome, turma_id, professor } = req.body;
  try {
    const [result] = await db.execute(
      "INSERT INTO disciplinas (nome, turma_id, professor) VALUES (?, ?, ?)",
      [nome, turma_id, professor]
    );
    await firestore
      .collection("disciplinas")
      .doc(result.insertId.toString())
      .set(req.body);
    res.json({ message: "Disciplina criada!", id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao criar disciplina");
  }
});

app.get("/disciplinas", async (req, res) => {
  try {
    const [rows] = await db.execute("SELECT * FROM disciplinas");
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao listar disciplinas");
  }
});

// --- FREQUÊNCIAS ---
app.post("/frequencias", async (req, res) => {
  const { aluno_id, disciplina_id, data, presente } = req.body;
  try {
    const [result] = await db.execute(
      "INSERT INTO frequencias (aluno_id, disciplina_id, data, presente) VALUES (?, ?, ?, ?)",
      [aluno_id, disciplina_id, data, presente]
    );
    await firestore
      .collection("frequencias")
      .doc(result.insertId.toString())
      .set(req.body);
    res.json({ message: "Frequência registrada!", id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao registrar frequência");
  }
});

app.get("/frequencias/:aluno_id", async (req, res) => {
  const { aluno_id } = req.params;
  try {
    const [rows] = await db.execute(
      "SELECT * FROM frequencias WHERE aluno_id=?",
      [aluno_id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao listar frequências");
  }
});

// --- NOTAS ---
app.post("/notas", async (req, res) => {
  const { aluno_id, disciplina_id, bimestre, nota } = req.body;
  try {
    const [result] = await db.execute(
      "INSERT INTO notas (aluno_id, disciplina_id, bimestre, nota) VALUES (?, ?, ?, ?)",
      [aluno_id, disciplina_id, bimestre, nota]
    );
    await firestore
      .collection("notas")
      .doc(result.insertId.toString())
      .set(req.body);
    res.json({ message: "Nota registrada!", id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao registrar nota");
  }
});

app.get("/notas/:aluno_id", async (req, res) => {
  const { aluno_id } = req.params;
  try {
    const [rows] = await db.execute("SELECT * FROM notas WHERE aluno_id=?", [
      aluno_id,
    ]);
    const total = rows.reduce((acc, r) => acc + r.nota, 0);
    const media = rows.length ? total / rows.length : 0;
    res.json({ notas: rows, media });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao listar notas");
  }
});

// ================== INICIAR SERVIDOR ==================
app.listen(PORT, () => console.log(`API rodando na porta ${PORT}`));
