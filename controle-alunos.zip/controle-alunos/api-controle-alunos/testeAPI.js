import axios from "axios";

async function testAPI() {
  const turma = await axios.post("http://localhost:5000/turmas", {
    nome: "Turma A",
    curso: "Matemática",
  });
  console.log(turma.data);

  const aluno = await axios.post("http://localhost:5000/alunos", {
    nome: "João Silva",
    data_nascimento: "2005-03-15",
    endereco: "Rua A, 123",
    telefone: "123456789",
    email: "joao@email.com",
    cpf: "12345678901",
    rg: "MG123456",
    foto: "",
    turma_id: turma.data.id,
    status: "ativo",
  });
  console.log(aluno.data);
}

testAPI();
