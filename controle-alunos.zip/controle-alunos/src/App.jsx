import AlunoForm from "./components/AlunoForm";
import AlunoList from "./components/AlunoList";
import "./styles/main.css";

function App() {
  return (
    <div className="container">
      <h1>🎓 Controle de Alunos</h1>
      <AlunoForm />
      <AlunoList />
    </div>
  );
}

export default App;
