import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCiI5NNjlJIFSvNVflr_RR3mBTKdtcjpjI",
  authDomain: "controledealunos-c6138.firebaseapp.com",
  projectId: "controledealunos-c6138",
  storageBucket: "controledealunos-c6138.firebasestorage.app",
  messagingSenderId: "515461656915",
  appId: "1:515461656915:web:1fac6fe41e1f57902f31a6",
};

// Inicializa Firebase
const app = initializeApp(firebaseConfig);

// Exporta banco e storage
export const db = getFirestore(app);
export const storage = getStorage(app);
